# Zippy_Codes
Codes I used in my YouTube videos

To run the games you have to install the ursina module. 
In case you're using PyCharm, I made a tutorial on how to install ursina
(https://www.youtube.com/watch?v=esDfJFi7igQ)

All used assets (e.g. sprites, 3d objects) are in the assets folder. You can download simple the whole assets folder.


Credits for the Robots 3D Animation Code:
"Old Robot" (https://skfb.ly/6zqLK) by Alexander Badrak is licensed 
under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).

I changed the robot by removing the fingers. And I created slight variations from the robot to
have 10 frames for the animation (different arm and leg positions)
